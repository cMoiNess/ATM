import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //CLI cli = new CLI();
        //cli.powerCLI();
        ATM_GUI GUI = new ATM_GUI();
        GUI.powerGUI();
    }
}